from xlutils.copy import copy
import xlrd

#打开excel表格
workbook = xlrd.open_workbook('D:\学习文档\python3_Pycharm\get_excel/test.xls')

#复制excel表格
copy_workbook = copy(workbook)

#获取第一个分表,get_sheet()是xlutils库的函数
sheet1 = copy_workbook.get_sheet(0)

#写入内容write(row,clo,value)
sheet1.write(3,5,'test1')

#保存在特定路径
copy_workbook.save('D:\学习文档\python3_Pycharm\get_excel/test.xls')


