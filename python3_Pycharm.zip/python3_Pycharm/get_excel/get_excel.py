#引入操控excel表的库
import xlrd

#打开excel表格,excel中有多少个分表，返回的list中就会有多少个对象
workbook = xlrd.open_workbook('D:\学习文档\python3_Pycharm\get_excel/test.xls')

#根据下表读取excel表格中的分表(对象)
sheet1 = workbook.sheets()[0]
#第二种方法，根据分表表名获取
sheet2 = workbook.sheet_by_name('Sheet2')
#第三种方法，根据分表下表获取
sheet3 = workbook.sheet_by_index(2)

#获取所有分表的表名
sheet_name = workbook._sheet_names

#获取分表中数据行数
rows = sheet1.nrows

#获取分表中数据列表
columns = sheet1.ncols

#根据行数下标获取整行数据
data_row = sheet1.row_values(0)

#根据列数下标获取整列数据
data_clo = sheet1.col_values(0)