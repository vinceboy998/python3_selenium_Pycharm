import unittest
from selenium import webdriver
import time
class Test_Case(unittest.TestCase):

    def create_driver(self):
        driver = webdriver.Chrome()
        driver.get('https://itemd05-qa-web.shanxilmd.com:9050/admin')
        return driver

    def test_case01(self):
        driver = self.create_driver()
        time.sleep(5)
        user_element = driver.find_element_by_name('username')
        user_element.send_keys('vincevince')
        password_element = driver.find_element_by_name('password')
        password_element.send_keys('123456')
        click_element = driver.find_element_by_class_name('btn')
        click_element.click()
        self.assertTrue(self.get_text(), '登录失败')


    def test_case02(self):
        driver = self.create_driver()
        time.sleep(5)
        user_element = self.driver.find_element_by_name('username')
        user_element.send_keys('admin')
        password_element = driver.find_element_by_name('password')
        password_element.send_keys('admin')
        click_element = driver.find_element_by_class_name('btn')
        click_element.click()
        try:
            self.assertTrue(self.get_text(), '登录失败')
        except:
            self.get_error(driver)


    def get_error(self,driver):
        for method_name,error in self._outcome_errors:
            if error:
                case_name = self._testMethodName
                self.driver.save_screenshot()
        self.driver.close()





    def get_text(self):
        time.sleep(2)
        text_element = self.driver.find_element_by_class_name('control-label')
        user_text = text_element.text
        if user_text == None:
            return False
        else:
            return True