import ddt
import unittest

@ddt.ddt
class Test_Case(unittest.TestCase):


    def setUp(self):
        print('这是setUp')

    def tearDown(self):
        print('这是tearDown')

    # @ddt.data([1,2],[3,4],[5,6]) #添加数据包
    # @ddt.unpack   #解包

    # data = [[1,1],[3,4],[5,6]]

    # @ddt.data(*data)
    @ddt.data([[1,1],[3,4],[5,6]])
    @ddt.unpack
    def test_case01(self,data):
        a,b = data
        print(a+b)



if __name__ == '__main__':
    unittest.main()
