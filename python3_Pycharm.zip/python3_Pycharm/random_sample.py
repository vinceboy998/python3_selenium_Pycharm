#生成随机数的模块
import random

for x in range(5):
    #获取随机7位数，从传入的population随机选取7个数，返回一个列表
    result_list = random.sample('123456789adbcde',7)
    print(result_list)
    #使用join函数，将result_list转化为字符串
    result_str = ''.join(result_list)
    print(result_str)
    print('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')




