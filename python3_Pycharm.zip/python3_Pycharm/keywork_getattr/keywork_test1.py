
class KeyworkTest():

    def sum(self,a,b,c):
        print(a+b+c)

    def subtraction(self,d,f):
        print(d-f)

    def multi(self,g):
        print(g*g)

#赋值函数名,可以直接读表
fun = 'multi'
#实例化方法
keywortest = KeyworkTest()

#将对象和函数名传入getattr方法中
methon = getattr(keywortest,fun)
print(type(methon))
methon(10)




