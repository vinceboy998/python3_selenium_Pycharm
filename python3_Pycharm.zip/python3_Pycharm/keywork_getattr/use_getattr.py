from keywork_getattr.keywork_test1 import KeyworkTest

fun = 'multi'
keywortest = KeyworkTest()

methon = getattr(keywortest,fun)
methon(10)