from selenium import  webdriver
#导入成像库的Image模块
from PIL import Image
import time

driver = webdriver.Chrome()
driver.get('https://www.imooc.com/user/newlogin')
driver.find_element_by_name('email').send_keys('1040021884@qq.com')
driver.find_element_by_name('password').send_keys('123456')
element = driver.find_element_by_css_selector('.rlf-group>.moco-btn')
element.click()
# print(element.location)
# print(element.size)

time.sleep(2)
driver.save_screenshot('D:\学习文档\python3_Pycharm/test0.png')
p_element = driver.find_element_by_class_name('verify-img')

coordinate_left = p_element.location  #获取验证码图片左下方点的坐标
left_x = coordinate_left['x']
left_y = coordinate_left['y']

p_size = p_element.size              #获取验证码图片的尺寸，宽和高
p_width = p_size['width']
p_height = p_size['height']

right_top_x = left_x + p_width     #获取验证码图片右上角点的x坐标
right_top_y = left_y + p_height    #获取验证码图片右上角点的y坐标

#打开一张图片
p_im = Image.open('D:\学习文档\python3_Pycharm/test0.png')
#根据坐标裁剪图片
img = p_im.crop((left_x,left_y,right_top_x,right_top_y))
#将裁剪后的图片保存
img.save('D:\学习文档\python3_Pycharm/test1.png')

driver.close()