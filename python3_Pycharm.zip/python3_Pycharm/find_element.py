from selenium import webdriver
import read_config as co
import time

class Find_Element(object):

    driver = webdriver.Chrome()
    driver.get('https://itemd05-qa-web.shanxilmd.com:9050/admin')
    time.sleep(5)

    def __init__(self):
        self.driver = Find_Element.driver

    def find_element(self,by,value):
        element = None
        if by == 'ID':
            element = self.driver.find_element_by_id(value)
        elif by == 'XPATH':
            element = self.driver.find_element_by_xpath(value)
        elif by == 'NAME':
            element = self.driver.find_element_by_name(value)
        elif by == 'CLASS_NAME':
            element = self.driver.find_element_by_class_name(value)
        elif by == 'LINK_TEXT':
            element = self.driver.find_element_by_link_text(value)
        elif by == 'PARTIAL_LINK_TEXT':
            element = self.driver.find_element_by_partial_link_text(value)
        elif by == 'TAG_NAME':
            element = self.driver.find_element_by_tag_name(value)
        elif by == 'CSS_SELECTOR':
            element = self.driver.find_element_by_css_selector(value)

        return element


test_find_element = Find_Element()
test_find_element.find_element(co.username_by,co.username_value).send_keys(co.username)


time.sleep(5)
test_find_element.driver.close()


