from page.register_page import RegisterPage

class Register_Handle(object):
    def __init__(self):
        self.register_pa = RegisterPage()

    #输入邮箱
    def send_user_email(self,email):
        self.register_pa.get_email_element().send_keys(email)
    #输入用户名
    def send_username(self):
        pass
    #输入密码
    def send_userpassword(self):
        pass
    #输入验证码
    def send_code(self):
        pass
    #获取提示信息
    def get_user_text(self,user_info):
        pass

    #点击注册按钮
    def click_register_button(self):
        pass
