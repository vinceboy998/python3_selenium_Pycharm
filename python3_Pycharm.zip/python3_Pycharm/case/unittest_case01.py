'''
#导入unittest框架
import unittest
#创建要给类，继承unittest的TestCase类
class FistCase01(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        print('这是所有case的前置条件')

    @classmethod
    def tearDownClass(cls):
        print('这是所有case的后置条件')

    def setUp(self):
        print('这是case的前置条件')

    def tearDown(self):
        print('这是case的后置条件')

    #函数名开头加test调用main()函数的时候，case才会被执行
    def testfirst01(self):
        print('这是第一条case')
    def testfirst02(self):
        print('这是第二条case')

if __name__ == '__main__':
    unittest.main()
'''

#容器式
'''
import unittest
class FirstCase02(unittest.TestCase):

    def testfirst01(self):
        print('这是第一条case')

    def testfirst02(self):
        print('这是第二条case')
    def testfirst03(self):
        print('这是第三条case')

if __name__ == '__main__':
    #实例化unittest.TestSuite
    suite = unittest.TestSuite()
    #执行哪个类中的哪些case
    suite.addTest(FirstCase02(('testfirst02')))
    suite.addTest(FirstCase02(('testfirst01')))
    #执行suite容器中的case
    unittest.TextTestRunner().run(suite)
'''

#跳过case
import unittest
class FirstCase03(unittest.TestCase):

    @unittest.skip('跳过testfirst01这条case')
    def testfirst01(self):
        print('这是第一条case')

    def testfirst02(self):
        print('这是第二条case')
    def testfirst03(self):
        print('这是第三条case')

if __name__ == '__main__':
    unittest.main()

