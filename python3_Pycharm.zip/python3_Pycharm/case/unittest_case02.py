import unittest
class FirstCase03(unittest.TestCase):

    @unittest.skip('跳过testfirst01这条case')
    def testfirst01(self):
        print('这是第1条case')

    def testfirst02(self):
        print('这是第2条case')
    def testfirst03(self):
        print('这是第3条case')

if __name__ == '__main__':
    unittest.main()