from business.register_business import RegisterBusiness

class FirstCase(object):
    def __init__(self):
        self.login = RegisterBusiness()

    def test_login_email_error(self):
        self.login.login(email='111@222')
        #通过assert判断是否为error

    def test_login_username_error(self):
        self.login.login(username='111')

    def test_login_password_error(self):
        self.login.login(userpassword='2222')

    def test_login_code_error(self):
        self.login.login(code = 'abcd')

    def test_login_success(self):
        self.login.login(email='1',username='2',userpassword='3',code='4')




