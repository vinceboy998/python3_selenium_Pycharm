import unittest
import os

class RunCase(unittest.TestCase):
    def test_runtest(self):
        #获取当前目录
        # case_path = os.path.join(os.getcwd())
        case_path = os.getcwd()
        print(case_path)
        #批量执行多个case
        suite = unittest.defaultTestLoader.discover(case_path,'unittest_*.py')
        #执行容器
        unittest.TextTestRunner().run(suite)

if __name__ == '__main__':
    unittest.main()

