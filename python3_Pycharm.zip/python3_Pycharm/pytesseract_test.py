from PIL import Image
#图像文字识别库
import pytesseract

im = Image.open('D:\学习文档\python3_Pycharm/test2.bmp')
text = pytesseract.image_to_string(im)
print(text)