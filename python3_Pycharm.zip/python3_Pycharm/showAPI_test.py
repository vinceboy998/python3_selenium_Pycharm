from ShowapiRequest import ShowapiRequest

#my_appId:你在showAPI上的ID
#my__appSecret:你在showAPI上的密钥
r = ShowapiRequest("http://route.showapi.com/184-4","my_appId","my__appSecret")
r.addBodyPara("typeId","34")        #验证码的长度，几位数,34表示4位
r.addBodyPara("convert_to_jpg","0")
r.addFilePara("image",r"D:\学习文档\python3_Pycharm\test1.png")   #上传文件配置
res = r.post()
text = res.json()
print(text)  # 返回信息



from ShowapiRequest import ShowapiRequest

r = ShowapiRequest("http://route.showapi.com/1274-2","136182","844baec6896c47fc85ed9a5800baa7e8" )
# r.addBodyPara("imgUrl", "http://pic.4j4j.cn/upload/pic/20130528/a9117a5351.jpg")
r.addBodyPara("base64", "")
r.addFilePara("imgFile", r"D:\学习文档\python3_Pycharm\test1.png")
res = r.post()
print(res.text) # 返回信息