from selenium import webdriver
import unittest
import os
import HTMLTestRunner
class Test01(unittest.TestCase):

    def setUp(self):
        self.driver = webdriver.Chrome()
        self.driver.get('https://itemd05-qa-web.shanxilmd.com:9050/admin')

    def test_case01(self):
        self.assertTrue(False,'case1执行失败')

    def test_case02(self):
        self.assertTrue(True,'case执行通过')
        print(1)

    #h后置条件
    def tearDown(self):
        #访问处理case失败的list
        print(self._outcome.errors)
        for method_name,error in self._outcome.errors:
            if error:
                #获得执行失败case的函数名
                case_name = self._testMethodName
                # file_name = os.getcwd()+'\\%s.png' %case_name
                self.driver.save_screenshot('D:\学习文档\python3_Pycharm\\test'+'\\%s.png'%case_name)
                # self.driver.save_screenshot(file_name)
                # self.driver.close()
        self.driver.close()

if __name__ == '__main__':

    file_path = r'D:\学习文档\python3_Pycharm\report/first_case.html'
    f = open(file_path,'wb')
    suite = unittest.TestLoader().loadTestsFromTestCase(Test01)
    runner = HTMLTestRunner.HTMLTestRunner(stream = f, title='This is a first report1', description=u'第一个测试报告', verbosity=2)
    runner.run(suite)
