from selenium import webdriver
from selenium import webdriver
import unittest
import os
import time
import sys
sys.path.append('D:\学习文档\python3_Pycharm')
from log_test.log_test3 import Log_Write



class Test01(unittest.TestCase):



    def setUp(self):
        self.driver = webdriver.Chrome()
        self.driver.get('https://itemd05-qa-web.shanxilmd.com:9050/admin')

    def test_case01(self):
        time.sleep(5)
        self.assertTrue(False,'case1执行失败')

    def test_case02(self):
        self.assertTrue(True,'case执行通过')
        time.sleep(10)
        print(1)

    #h后置条件
    def tearDown(self):
        #访问处理case失败的list
        # print(self._outcome.errors)
        logger = Log_Write()
        # logger.log_write().debug(self._outcome.errors)
        logger.log_write().error(self._outcome.errors)
        logger.log_close()


        # logger.debug(self._outcome.errors)
        for method_name,error in self._outcome.errors:
            if error:
                #获得执行失败case的函数名
                case_name = self._testMethodName
                # file_name = os.getcwd()+'\\%s.png' %case_name
                self.driver.save_screenshot('D:\学习文档\python3_Pycharm\\test'+'\\%s.png'%case_name)
                # self.driver.save_screenshot(file_name)
                self.driver.close()
            else:
                self.driver.close()

if __name__ == '__main__':
    unittest.main()