import unittest
import os
import HTMLTestRunner

class FirstCase02(unittest.TestCase):

    def testfirst01(self):
        print('这是第一条case')

    def testfirst02(self):
        print('这是第二条case')
    def testfirst03(self):
        self.assertFalse(True,'失败')
        print('这是第三条case')



if __name__ == '__main__':
    #实例化unittest.TestSuite
    suite = unittest.TestSuite()
    #执行哪个类中的哪些case
    suite.addTest(FirstCase02(('testfirst02')))
    suite.addTest(FirstCase02(('testfirst03')))
    suite.addTest(FirstCase02(('testfirst01')))
    # case_path = os.path.join(os.getcwd()+'/report/'+'first_case.html')
    case_path = r'D:\学习文档\python3_Pycharm\report/first_case.html'
    #读写模式打开first_case.html
    f = open(case_path,'wb')
    runner = HTMLTestRunner.HTMLTestRunner(stream=f,title='This is a first report',description=u'第一个测试报告',verbosity=2)
    runner.run(suite)
