import os
import time
import logging

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

#获取当前文件上级目录路径
base = os.getcwd()
today=(time.strftime('%Y-%m-%d'))
#拼接路径
file_path = os.path.join(base,today+'.log')

file_handler = logging.FileHandler(file_path)
formatter = logging.Formatter('%(asctime)s %(filename)s --》%(funcName)s %(levelno)s %(levelname)s %(message)s')
file_handler.setFormatter(formatter)

logger.addHandler(file_handler)

logger.debug('测试测试')

file_handler.close()
logger.removeHandler(file_handler)












#获取当前文件路径。
# path2 = os.path.abspath(__file__)
# print(path2)