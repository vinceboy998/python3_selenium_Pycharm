#封装
import time
import os
import logging

class Log_Write(object):

    def __init__(self):
        self.logger = self.log_write()

    def log_write(self):
        logger = logging.getLogger()
        # logger.setLevel(logging.DEBUG)
        logger.setLevel(logging.ERROR)
        base = os.getcwd()
        today = (time.strftime('%Y-%m-%d'))
        file_path = os.path.join(base, today + '.log')
        self.file_handler = logging.FileHandler(file_path)
        # self.file_handler.setLevel(logging.DEBUG)
        self.file_handler.setLevel(logging.ERROR)
        formatter = logging.Formatter('%(asctime)s %(filename)s --》%(funcName)s %(levelno)s %(levelname)s %(message)s')
        self.file_handler.setFormatter(formatter)
        logger.addHandler(self.file_handler)
        return logger

    #第一种方法，将关闭日志对象的代码单独封装
    def log_close(self):
        self.file_handler.close()
        self.logger.removeHandler(self.file_handler)
