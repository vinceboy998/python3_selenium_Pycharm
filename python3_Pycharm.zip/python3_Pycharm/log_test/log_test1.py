import logging

#实例化对象
logger = logging.getLogger()
#设置日志等级,logging共有五种级别：DEBUG、INFO、WARNING、ERROR、CRITICAL
logger.setLevel(logging.DEBUG)

#控制台输出日志
#实例化控制台流对象，日志会打印在控制台。
# consle_handlder = logging.StreamHandler()
# logger.addHandler(consle)

#文件输出日志
#实例化文件流对象，日志会打印在特定的文件中
file_handlder = logging.FileHandler('D:\学习文档\python3_Pycharm\log_test/test.log')

formatter = logging.Formatter('%(asctime)s %(filename)s --》%(funcName)s %(levelno)s %(levelname)s %(message)s ')
file_handlder.setFormatter(formatter)


logger.addHandler(file_handlder)


#打印日志
logger.debug('test1234')

#关闭流对象
file_handlder.close()
#移除Handler
logger.removeHandler(file_handlder)



