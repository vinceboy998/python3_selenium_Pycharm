import configparser

config = configparser.ConfigParser()

config.read(r'D:\学习文档\python3_Pycharm/config.ini')

read_username = config.get('login','username')
read_password = config.get('login','password')

read_username_list = read_username.split('>')
read_password_list = read_password.split('>')


username_by = read_username_list[0]
username_value = read_username_list[1]
username = read_username_list[2]
password_by = read_password_list[0]
password_value = read_password_list[1]
password = read_password_list[1]


print(username_by)
