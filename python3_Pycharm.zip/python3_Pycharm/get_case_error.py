from selenium import webdriver
import unittest
import os
import unittest
import HTMLTestRunner
import time

class Login_D05(unittest.TestCase):

    def test_runcase(self):
        case_path = os.getcwd()
        #加载case文件中的case
        suite = unittest.defaultTestLoader.discover(case_path,'test_case*.py')
        # unittest.TextTestRunner().run(suite)
        case_path = r'D:\学习文档\python3_Pycharm\report/first_case.html'
        f = open(case_path, 'wb')
        #生成测试报告
        runner = HTMLTestRunner.HTMLTestRunner(stream=f, title='This is a first report', description=u'第一个测试报告',verbosity=2)
        runner.run(suite)

if __name__ == '__main__':

    unittest.main()


