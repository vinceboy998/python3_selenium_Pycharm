from selenium import webdriver
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()
driver.get('https://itemd05-qa-web.shanxilmd.com:9050/admin/auth/login')
locator = (By.NAME,'username')
# result = EC.visibility_of_element_located(locator)

#等待60秒,异常报出123456
WebDriverWait(driver,1).until(EC.visibility_of_element_located(locator),message='123456')

driver.close()




