from handle.register_handle import  Register_Handle

class RegisterBusiness(object):
    def __init__(self):
        self.register = Register_Handle()
    # 执行操作
    def login(self,email = None,username = None,userpassword = None,code = None):
        self.register.send_user_email(email)
        if self.register.get_user_text('请输入有效的邮箱地址'):
            print('邮箱检验成功')
            return True
        self.register.send_username(username)
        if self.register.get_user_text('请输入有效的用户名'):
            print('用户名检验成功')
            return True
        self.register.send_userpassword(userpassword)
        if self.register.get_user_text('请输入正确的密码'):
            print('密码检验成功')
            return True
        self.register.send_code(code)
        if self.register.get_user_text('请输入正确的验证码'):
            print('验证码检验成功')
            return True

