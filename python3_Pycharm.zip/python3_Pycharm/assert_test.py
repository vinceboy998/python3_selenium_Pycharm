import unittest

class Test(unittest.TestCase):

    def test_case(self):
        #结果为True,报错并打印后面的‘测试1’
        self.assertFalse(True,'测试1')

        # 判断结果是否为False,是的话继续执行后面的代码
        self.assertFalse(False,'测试2')
        print(1)

if __name__ == '__main__':
    unittest.main()


