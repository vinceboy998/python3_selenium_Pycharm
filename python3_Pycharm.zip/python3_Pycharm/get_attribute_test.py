from selenium import webdriver
import time

driver = webdriver.Chrome()
driver.get('https://itemd05-qa-web.shanxilmd.com:9050/admin/auth/login')
time.sleep(5)
user_element = driver.find_element_by_name('username')
password_element = driver.find_element_by_name('password')

#获取输入框中自带的信息，想要获取哪个属性，把那个属性当作参数传入即可
user_attribute = user_element.get_attribute('placeholder')
print(user_attribute)

#获取我们写入输入框中的内容，传入参数'value'即可
user_element.send_keys('admin')
password_element.send_keys('vince')
user_attribute = user_element.get_attribute('value')
password_attribute = password_element.get_attribute('value')
print(user_attribute)
print(password_attribute)
time.sleep(5)
driver.close()