from find_element import Find_Element

class RegisterPage(object):

    def __init__(self):
        self.find_element = Find_Element()
    #读取配置中的元素
    def get_email_element(self,by,value):
        element = self.find_element.find_element(by,value)
    def get_username_element(self):
        pass
    def get_userpassword_element(self):
        pass
    def get_code_element(self):
        pass

    return element